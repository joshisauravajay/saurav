package com.example.voterlist;

import android.Manifest;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.ViewModelProviders;

import com.example.voterlist.database.DatabaseClass;
import com.example.voterlist.entity.EmployeeData;
import com.example.voterlist.viewModel.VoterViewModel;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import java.util.Random;

public class Form  extends AppCompatActivity {
    EditText e_voterid, e_firstname, e_lastname, e_age, e_bloodgroup, e_dob, e_phone, e_email, e_street, e_city, e_state, e_country, e_zipcode, e_marital, e_aadhar, e_pan, e_father, e_mother;
    VoterViewModel voterViewModel;
    long s;
    Button button_Camera;
    Bitmap captureimage;
    //For displaying calender
    final Calendar myCalendar = Calendar.getInstance();
    final DatePickerDialog.OnDateSetListener date = (view, year, monthOfYear, dayOfMonth) -> {
        // TODO Auto-generated method stub
        myCalendar.set(Calendar.YEAR, year);
        myCalendar.set(Calendar.MONTH, monthOfYear);
        myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
        updateLabel();
    };

    private void updateLabel() {
        String myFormat = "dd/MM/yyyy"; //In which you need put here
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

        e_dob.setText(sdf.format(myCalendar.getTime()));
    }//calender


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.save, menu);
        return true;
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        voterViewModel = ViewModelProviders.of(this).get(VoterViewModel.class);
        setContentView(R.layout.activity_form);
//        button_Camera = findViewById(R.id.bt_open);
//
//        if (ContextCompat.checkSelfPermission(Form.this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED){
//            ActivityCompat.requestPermissions(Form.this, new String[]{
//                    Manifest.permission.CAMERA
//            }, 100);
//        }
//
//        button_Camera.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
//                startActivityForResult(intent,100);
//            }
//
//        });
//    }
//    @Override
//    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
//        if (requestCode == 100) {
//            captureimage = (Bitmap) data.getExtras().get("data");
//            super.onActivityResult(requestCode, resultCode, data);
//
//        }
        e_dob = findViewById(R.id.edittext_DOB);
        ActionBar actionBar = getSupportActionBar();
        assert actionBar != null;
        actionBar.setDisplayHomeAsUpEnabled(true);
        //calender
        e_dob.setOnClickListener(v -> {
            //TODO Auto-generated method stub
            new DatePickerDialog(Form.this, date, myCalendar
                    .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                    myCalendar.get(Calendar.DAY_OF_MONTH)).show();
        });//calender
        e_voterid = findViewById(R.id.edittext_Id);
        e_firstname = findViewById(R.id.edittext_Firstname);
        e_lastname = findViewById(R.id.edittext_Lastname);
        e_age = findViewById(R.id.edittext_Age);
        e_bloodgroup = findViewById(R.id.edittext_Bloodgroup);
        e_phone = findViewById(R.id.edittext_Phone);
        e_email = findViewById(R.id.edittext_Email);
        e_street = findViewById(R.id.edittext_Street);
        e_city = findViewById(R.id.edittext_City);
        e_state = findViewById(R.id.editText_State);
        e_country = findViewById(R.id.edittext_Country);
        e_zipcode = findViewById(R.id.edittext_Pincode);
        e_marital = findViewById(R.id.edittext_Marital);
        e_aadhar = findViewById(R.id.edittext_Aadhar);
        e_pan = findViewById(R.id.edittext_Pan);
        e_father = findViewById(R.id.edittext_Fathername);
        e_mother = findViewById(R.id.edittext_Mothername);

    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.save) {
            validate();
        }
        if (item.getItemId() == android.R.id.home) {
            Toast.makeText(getApplicationContext(), "Back Button Clicked", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(getApplicationContext(), MainActivity.class));
        }
        if (item.getItemId() == R.id.myfill) {
            fillData();
        }
        return super.onOptionsItemSelected(item);
    }

    public void validate() {
        //Storing the input entered by user in different strings.
        String voterid_txt = e_voterid.getText().toString().trim();
        String firstname_txt = e_firstname.getText().toString().trim();
        String lastname_txt = e_lastname.getText().toString().trim();
        String age_txt = e_age.getText().toString().trim();
        String bloodgroup_txt = e_bloodgroup.getText().toString().trim();
        String dob_txt = e_dob.getText().toString().trim();
        String phone_txt = e_phone.getText().toString().trim();
        String email_txt = e_email.getText().toString().trim();
        String street_txt = e_street.getText().toString().trim();
        String city_txt = e_city.getText().toString().trim();
        String state_txt = e_state.getText().toString().trim();
        String country_txt = e_country.getText().toString().trim();
        String zipcode_txt = e_zipcode.getText().toString().trim();
        String marital_txt = e_marital.getText().toString().trim();
        String aadhar_txt = e_aadhar.getText().toString().trim();
        String pan_txt = e_pan.getText().toString().trim();
        String father_txt = e_father.getText().toString().trim();
        String mother_txt = e_mother.getText().toString().trim();


        int flag = 0;
        if (!voterid_txt.matches("[0-9]+")) {
            e_voterid.requestFocus();
            e_voterid.setError("ID should be a number");
            flag = 1;
        }
        if (voterid_txt.length() != 4) {
            e_voterid.requestFocus();
            e_voterid.setError("Please enter 4 digit number only");
            flag = 1;
        }
        if (!firstname_txt.matches("[A-Z]([a-z]*|[A-Z]*)")) {
            e_firstname.requestFocus();
            e_firstname.setError("Invalid Firstname");
            flag = 1;
        }
        if (firstname_txt.length() == 0) {
            e_firstname.requestFocus();
            e_firstname.setError("Field cannot be empty");
            flag = 1;
        }
        if (!lastname_txt.matches("[A-Z]([a-z]*|[A-Z]*)")) {
            e_lastname.requestFocus();
            e_lastname.setError("Invalid Lastname");
            flag = 1;
        }
        if (lastname_txt.length() == 0) {
            e_lastname.requestFocus();
            e_lastname.setError("Field cannot be empty");
            flag = 1;
        }
        if (dob_txt.length() == 0) {
            e_dob.requestFocus();
            e_dob.setError("Field cannot be empty");
            flag = 1;
        }
        if (!phone_txt.matches("[2-9][0-9]{9}")) {
            e_phone.requestFocus();
            e_phone.setError("Invalid Phone Number");
            flag = 1;
        }
        if (phone_txt.length() == 0) {
            e_phone.requestFocus();
            e_phone.setError("Field cannot be empty");
            flag = 1;
        }

        if (age_txt.matches("[a-zA-Z]+")) {
            e_age.requestFocus();
            e_age.setError("Age should be in digits");
            flag = 1;
        }
        if (age_txt.length() == 0) {
            e_age.requestFocus();
            e_age.setError("Field cannot be empty");
            flag = 1;
        }
        if (!email_txt.matches("^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$")) {
            e_email.requestFocus();
            e_email.setError("Invalid email");
            flag = 1;
        }

        if (email_txt.length() == 0) {
            e_email.requestFocus();
            e_email.setError("Field cannot be empty");
            flag = 1;
        }

        if (!street_txt.matches("[A-Z]([a-z]*|[A-Z]*)")) {
            e_street.requestFocus();
            e_street.setError("Invalid");
            flag = 1;
        }

        if (street_txt.length() == 0) {
            e_street.requestFocus();
            e_street.setError("Field cannot be empty");
            flag = 1;
        }

        if (!state_txt.matches("[A-Z]([a-z]*|[A-Z]*)")) {
            e_state.requestFocus();
            e_state.setError("Invalid");
            flag = 1;
        }

        if (state_txt.length() == 0) {
            e_state.requestFocus();
            e_state.setError("Field cannot be empty");
            flag = 1;
        }

        if (!city_txt.matches("[A-Z]([a-z]*|[A-Z]*)")) {
            e_city.requestFocus();
            e_city.setError("Invalid");
            flag = 1;
        }

        if (!country_txt.matches("[A-Z]([a-z]*|A-Z]*)")) {
            e_country.requestFocus();
            e_country.setError("Invalid");
            flag = 1;
        }

        if (country_txt.length() == 0) {
            e_country.requestFocus();
            e_country.setError("Field cannot be empty");
            flag = 1;
        }
        if (!zipcode_txt.matches("^[1-9][0-9]{2}\\s?[0-9]{3}$")) {
            e_zipcode.requestFocus();
            e_zipcode.setError("Invalid Zipcode");
            flag = 1;
        }
        if (zipcode_txt.length() != 6) {
            e_zipcode.requestFocus();
            e_zipcode.setError("Please enter 6 digit number only");
            flag = 1;
        }

        if (!marital_txt.equals("Married") && !marital_txt.equals("Unmarried") && !marital_txt.equals("married") && !marital_txt.equals("unmarried")) {
            e_marital.requestFocus();
            e_marital.setError("Invalid");
            flag = 1;
        }

        if (marital_txt.length() == 0) {
            e_marital.requestFocus();
            e_marital.setError("Field cannot be empty");
            flag = 1;
        }
        if (!aadhar_txt.matches("^[2-9][0-9]{3}[0-9]{4}[0-9]{4}$")) {
            e_aadhar.requestFocus();
            e_aadhar.setError("Invalid Aadhar");
            flag = 1;
        }

        if (aadhar_txt.length() != 12) {
            e_aadhar.requestFocus();
            e_aadhar.setError("Aadhar is 12 digit no");
            flag = 1;
        }
        if (!father_txt.matches("[A-Z]([a-z]*|[A-Z]*)")) {
            e_father.requestFocus();
            e_father.setError("Invalid");
            flag = 1;
        }
        if (father_txt.length() == 0) {
            e_father.requestFocus();
            e_father.setError("Field cannot be empty");
            flag = 1;
        }
        if (!mother_txt.matches("[A-Z]([a-z]*[A-Z]*)")) {
            e_mother.requestFocus();
            e_mother.setError("Invalid");
            flag = 1;
        }
        if (mother_txt.length() == 0) {
            e_mother.requestFocus();
            e_mother.setError("Field cannot be empty");
            flag = 1;
        }
        if (!pan_txt.matches("[A-Z]{5}[0-9]{4}[A-Z]")) {
            e_pan.requestFocus();
            e_pan.setError("Invalid Aadhar");
            flag = 1;
        }
        if (pan_txt.length() != 10) {
            e_pan.requestFocus();
            e_pan.setError("Length should be 10");
            flag = 1;
        }
        if (!bloodgroup_txt.matches("(A|B|AB|O)[+-]")) {
            e_bloodgroup.requestFocus();
            e_bloodgroup.setError("Invalid");
            flag = 1;
        }
        if (bloodgroup_txt.length() == 0) {
            e_bloodgroup.requestFocus();
            e_bloodgroup.setError("Field cannot be empty");
            flag = 1;
        }

        if (flag == 0) {
            saveData(); // Only if all the data entered by user is valid, it will be saved
            Log.d("TAG", "inside if "+flag);

        }
    }

    public void saveData() {

//Creating an object of class EmployeeData
        EmployeeData model = new EmployeeData();

        String voterid_txt = e_voterid.getText().toString().trim();
        String firstname_txt = e_firstname.getText().toString().trim();
        String lastname_txt = e_lastname.getText().toString().trim();
        String age_txt = e_age.getText().toString().trim();
        String bloodgroup_txt = e_bloodgroup.getText().toString().trim();
        String dob_txt = e_dob.getText().toString().trim();
        String phone_txt = e_phone.getText().toString().trim();
        String email_txt = e_email.getText().toString().trim();
        String street_txt = e_street.getText().toString().trim();
        String city_txt = e_city.getText().toString().trim();
        String state_txt = e_state.getText().toString().trim();
        String country_txt = e_country.getText().toString().trim();
        String zipcode_txt = e_zipcode.getText().toString().trim();
        String marital_txt = e_marital.getText().toString().trim();
        String aadhar_txt = e_aadhar.getText().toString().trim();
        String pan_txt = e_pan.getText().toString().trim();
        String father_txt = e_father.getText().toString().trim();
        String mother_txt = e_mother.getText().toString().trim();

        //Initializing the variables of the object of class
        model.setVoterid(voterid_txt);
        model.setFirstname(firstname_txt);
        model.setLastname(lastname_txt);
        model.setAge(age_txt);
        model.setBloodgroup(bloodgroup_txt);
        model.setDob(dob_txt);
        model.setPhone(phone_txt);
        model.setEmail(email_txt);
        model.setStreet(street_txt);
        model.setCity(city_txt);
        model.setState(state_txt);
        model.setCountry(country_txt);
        model.setZipcode(zipcode_txt);
        model.setMarital(marital_txt);
        model.setAadhar(aadhar_txt);
        model.setPan(pan_txt);
        model.setFather(father_txt);
        model.setMother(mother_txt);



        //Changes made here
        final Handler handler = new Handler(Looper.getMainLooper());
        Runnable runnable = new Runnable() {
            @Override
            public void run() {


                //Inserting the data stored in the object to the database

                s = voterViewModel.insertDetails(model);

                handler.post(new Runnable() {
                    @Override
                    public void run() {

                          if (s == -1)//If duplicate data is entered by user
                          {
                              e_voterid.setText("");
                              Toast.makeText(Form.this, "Duplicate data", Toast.LENGTH_SHORT).show();
                          }
                        else {
                              Toast.makeText(Form.this, "Data Successfully Saved", Toast.LENGTH_SHORT).show();
                              startActivity(new Intent(getApplicationContext(), MainActivity.class));
                          }
                    }

                });
            }

        };
        Thread thread = new Thread(runnable);
        thread.start();
        //Makes the input fields blank again


    }
    final int min=1000;
    final int max=9999;
    public void fillData() {
        int random = new Random().nextInt((max - min) + 1) + min;
        e_voterid.setText(Integer.toString(random));
        e_firstname.setText("Saurav");
        e_lastname.setText("Joshi");
        e_age.setText("23");
        e_bloodgroup.setText("A+");
        e_dob.setText("20/10/2000");
        e_phone.setText("9345465456");
        e_aadhar.setText("456765434567");
        e_pan.setText("DFRED3456R");
        e_email.setText("sauravjo@cybage.com");
        e_street.setText("Dfgh");
        e_state.setText("Maharashtra");
        e_city.setText("Pune");
        e_country.setText("India");
        e_marital.setText("Married");
        e_father.setText("Ajay");
        e_mother.setText("Indu");
        e_zipcode.setText("545654");

    }

    }

