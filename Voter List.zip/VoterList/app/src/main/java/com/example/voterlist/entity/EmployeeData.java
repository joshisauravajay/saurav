package com.example.voterlist.entity;

import androidx.room.Entity;
import androidx.room.Index;
import androidx.room.PrimaryKey;

@Entity(indices = {@Index(value="voterid",unique = true)})//Declares voterid unique
public class EmployeeData {

    @PrimaryKey(autoGenerate = true)//Primary key will be automatically generated
    int id;
    public String voterid;
    private String firstname;
    private String lastname;
    private String age;
    private String bloodgroup;
    private String phone;
    private String dob;
    private String email;
    private String aadhar;
    private String street;
    private String city;
    private String state;
    private String country;
    private String pan;
    private String zipcode;
    private String father;
    private String mother;
    private String marital;

// Defining getter and setter for the variables
    public int getId()
    {

        return this.id;
    }

    public void setId(int id) {
        this.id = id;
    }


    public String getVoterid()
    {
        return this.voterid;
    }

    public void setVoterid(String voterid) {
        this.voterid = voterid;
    }

    public String getFirstname() {
        return this.firstname;
    }

    public void setFirstname(String Firstname) {
        this.firstname = Firstname;
    }
    public String getLastname() {
        return this.lastname;
    }

    public void setLastname(String Lastname) {
        this.lastname = Lastname;
    }
    public String getAge() {
        return this.age;
    }

    public void setAge(String Age) {
        this.age = Age;
    }
   public String getBloodgroup() {
        return this.bloodgroup;
    }

    public void setBloodgroup(String Bloodgroup) {
        this.bloodgroup = Bloodgroup;}
    public String getPhone() {
        return this.phone;
    }

    public void setPhone(String Phone) {
        this.phone = Phone;
    }
    public String getDob() {
        return this.dob;
    }

    public void setDob(String Dob) {
        this.dob = Dob;
    }
    public String getEmail() {
        return this.email;
    }

    public void setEmail(String Email) {
        this.email = Email;
    }
    public String getStreet() {
        return this.street;
    }

    public void setStreet(String Street) {
        this.street = Street;
    }
    public String getCity() {
        return this.city;
    }

    public void setCity(String City) {
        this.city = City;
    }
    public String getState() {
        return this.state;
    }

    public void setState(String State) {
        this.state = State;
    }
    public String getCountry() {
        return this.country;
    }

    public void setCountry(String Country) {
        this.country= Country;
    }
    public String getAadhar() {
        return this.aadhar;
    }

    public void setAadhar(String Aadhar) {
        this.aadhar = Aadhar;
    }
    public String getPan() {
        return this.pan;
    }

    public void setPan(String Pan) {
        this.pan = Pan;
    }
    public String getZipcode() {
        return this.zipcode;
    }

    public void setZipcode(String Zipcode) {
        this.zipcode = Zipcode;
    }
    public String getMarital() {
        return this.marital;
    }

    public void setMarital(String Marital) {
        this.marital = Marital;
    }
    public String getMother() {
        return this.mother;
    }

    public void setMother(String Mother) {
        this.mother = Mother;
    }
    public String getFather() {
        return this.father;
    }

    public void setFather(String Father) {
        this.father = Father;
    }

    //Method to display some specific values in voter's list
    public String getList()
{
    return("ID:" + " " + voterid +"                                          " + firstname + " " + lastname+ "\n" + "Age:" + " " + age+"                                           "+"Bloodgroup:"+" " +bloodgroup);
}


   // Empty constructor
    public EmployeeData()
    {
        this.voterid= null;
        this.firstname =null;
        this.lastname=null;
        this.age=null;
       this.bloodgroup=null;
    }

}
