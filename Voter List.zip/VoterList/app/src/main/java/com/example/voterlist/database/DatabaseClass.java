package com.example.voterlist.database;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.example.voterlist.dao.EmployeeDao;
import com.example.voterlist.entity.EmployeeData;

@Database(entities = {EmployeeData.class}, version = 2, exportSchema = false)
public abstract class DatabaseClass extends RoomDatabase {

    public abstract EmployeeDao getDao();

    private static DatabaseClass instance;


    public static DatabaseClass getDatabase(final Context context) {
        if(instance == null) {
            synchronized (DatabaseClass.class) {
                //  instance = Room.databaseBuilder(context, DatabaseClass.class, "DATABASE").allowMainThreadQueries().build();

                instance = Room.databaseBuilder(context.getApplicationContext(),
                        DatabaseClass.class, "DATABASE")
                        .fallbackToDestructiveMigration().allowMainThreadQueries()
                        .build();
            }
        }

        return instance;


    }



}
