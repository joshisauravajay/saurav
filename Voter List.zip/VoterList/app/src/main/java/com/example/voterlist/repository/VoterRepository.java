package com.example.voterlist.repository;

import android.app.Application;

import androidx.lifecycle.LiveData;

import com.example.voterlist.dao.EmployeeDao;
import com.example.voterlist.database.DatabaseClass;
import com.example.voterlist.entity.EmployeeData;

import java.util.List;

public class VoterRepository {

    private EmployeeDao employeeDao;
    private LiveData<List<EmployeeData>> listData;
    private LiveData<EmployeeData> edata;


    public VoterRepository(Application application) {

        employeeDao = DatabaseClass.getDatabase(application).getDao();
    }

    public LiveData<List<EmployeeData>> getListData() {
        listData = employeeDao.getListData();
        return listData;
    }

    public LiveData<EmployeeData> getdatabyId(int id) {
        edata = employeeDao.getRow(id);
        return edata;
    }

    public long insert(EmployeeData employeeData) {
        return employeeDao.insertAllData(employeeData);

    }
}
