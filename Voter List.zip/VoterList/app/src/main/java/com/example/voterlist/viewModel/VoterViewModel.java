package com.example.voterlist.viewModel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.example.voterlist.entity.EmployeeData;
import com.example.voterlist.repository.VoterRepository;

import java.util.List;

public class VoterViewModel extends AndroidViewModel {


    public LiveData<List<EmployeeData>> viewlist;
    public VoterRepository voterRepository;
    public LiveData<EmployeeData> employeeData;

    public VoterViewModel(@NonNull Application application) {
        super(application);
        voterRepository = new VoterRepository(application);
    }

    public LiveData<List<EmployeeData>> viewgetlist() {
        //Retrieving some specific data from database and storing it in list
        viewlist = voterRepository.getListData();
        return viewlist;
    }

    public LiveData<EmployeeData> viewDetails(int id) {
        // Fetching and storing a database record in object of class EmployeeData using row id.
        employeeData = voterRepository.getdatabyId(id);
        return employeeData;
    }


    public long insertDetails(EmployeeData employeeData)
    {
        return voterRepository.insert(employeeData);
    }
}





