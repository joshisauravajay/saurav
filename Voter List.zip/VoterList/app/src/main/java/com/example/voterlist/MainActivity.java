package com.example.voterlist;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.voterlist.adapter.RecyclerViewAdapter;
import com.example.voterlist.database.DatabaseClass;
import com.example.voterlist.entity.EmployeeData;
import com.example.voterlist.viewModel.VoterViewModel;

import java.util.Collections;
import java.util.List;
import java.util.Random;


public class MainActivity extends AppCompatActivity {


    private RecyclerView recyclerview;
    VoterViewModel voterViewModel;

    @Override
    //adding add button
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.addbutton, menu);
        return super.onCreateOptionsMenu(menu);
    }
    // handle button activities
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.mybutton) {
            startActivity(new Intent(getApplicationContext(), Form.class));
        }

        return super.onOptionsItemSelected(item);
    }
    @Override
    protected void onCreate(Bundle savedinstanceState) {
        super.onCreate(savedinstanceState);
        voterViewModel= ViewModelProviders.of(this).get(VoterViewModel.class);
        setContentView(R.layout.activity_main);
        recyclerview = findViewById(R.id.review_list);
        getData_list();//Method to fetch key details of users from database
    }

    private void getData_list() {
        voterViewModel.viewgetlist().observe(this, new Observer<List<EmployeeData>>() {
            @Override
            public void onChanged(List<EmployeeData> employeeData) {
                display_list(employeeData);//Method to diplay list of users
            }
        });
    }

    private void display_list(List<EmployeeData>e) {
        //added data from list to adapter class
        RecyclerViewAdapter adapter = new RecyclerViewAdapter(e);
        Collections.reverse(e);
        // setting linear layout manager to implement linear view.
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        // at last set adapter to recycler view.
        recyclerview.setLayoutManager(layoutManager);
        recyclerview.setAdapter(adapter);
    }

}